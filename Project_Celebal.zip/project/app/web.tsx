import React from 'react';
import { View, StyleSheet } from 'react-native';
import WebLayout from '../components/WebLayout';
import HomeScreen from './(tabs)/index';
import CardsScreen from './(tabs)/cards';
import TransferScreen from './(tabs)/transfer';
import AnalyticsScreen from './(tabs)/analytics';
import ProfileScreen from './(tabs)/profile';

export default function WebApp() {
  const [activeTab, setActiveTab] = React.useState('home');

  const renderContent = () => {
    switch (activeTab) {
      case 'home':
        return <HomeScreen />;
      case 'cards':
        return <CardsScreen />;
      case 'transfer':
        return <TransferScreen />;
      case 'analytics':
        return <AnalyticsScreen />;
      case 'profile':
        return <ProfileScreen />;
      default:
        return <HomeScreen />;
    }
  };

  return (
    <View style={styles.container}>
      <WebLayout activeTab={activeTab} onTabChange={setActiveTab}>
        {renderContent()}
      </WebLayout>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
});