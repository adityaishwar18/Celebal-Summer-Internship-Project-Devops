import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Dimensions } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { CreditCard, Eye, EyeOff, Plus, MoveHorizontal as MoreHorizontal } from 'lucide-react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

const { width } = Dimensions.get('window');

export default function CardsScreen() {
  const [cardVisible, setCardVisible] = React.useState(true);

  const cards = [
    {
      id: 1,
      type: 'Debit',
      number: '•••• •••• •••• 4532',
      balance: 12847.50,
      colors: ['#1f2937', '#374151'],
      bank: 'SecureBank',
    },
    {
      id: 2,
      type: 'Credit',
      number: '•••• •••• •••• 8901',
      balance: 5420.00,
      colors: ['#3b82f6', '#1d4ed8'],
      bank: 'SecureBank',
    },
  ];

  const cardFeatures = [
    { icon: CreditCard, label: 'Card Details', description: 'View card information' },
    { icon: Eye, label: 'Show PIN', description: 'Reveal your PIN securely' },
    { icon: MoreHorizontal, label: 'Card Settings', description: 'Manage card preferences' },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>My Cards</Text>
          <TouchableOpacity style={styles.addButton}>
            <Plus size={20} color="#3b82f6" />
          </TouchableOpacity>
        </View>

        {/* Cards Carousel */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.cardsContainer}
          snapToInterval={width - 60}
          decelerationRate="fast"
        >
          {cards.map((card) => (
            <LinearGradient
              key={card.id}
              colors={card.colors}
              style={styles.card}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
            >
              <View style={styles.cardHeader}>
                <Text style={styles.cardBank}>{card.bank}</Text>
                <Text style={styles.cardType}>{card.type}</Text>
              </View>
              
              <View style={styles.cardMiddle}>
                <Text style={styles.cardNumber}>{card.number}</Text>
              </View>

              <View style={styles.cardFooter}>
                <View>
                  <Text style={styles.balanceLabel}>Available Balance</Text>
                  <View style={styles.balanceRow}>
                    <Text style={styles.balanceAmount}>
                      {cardVisible ? `$${card.balance.toLocaleString()}` : '••••••'}
                    </Text>
                    <TouchableOpacity onPress={() => setCardVisible(!cardVisible)}>
                      {cardVisible ? (
                        <Eye size={16} color="#ffffff" />
                      ) : (
                        <EyeOff size={16} color="#ffffff" />
                      )}
                    </TouchableOpacity>
                  </View>
                </View>
                <View style={styles.cardChip} />
              </View>
            </LinearGradient>
          ))}
        </ScrollView>

        {/* Card Features */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Card Management</Text>
          <View style={styles.featuresList}>
            {cardFeatures.map((feature, index) => (
              <TouchableOpacity key={index} style={styles.featureItem}>
                <View style={styles.featureIcon}>
                  <feature.icon size={24} color="#3b82f6" />
                </View>
                <View style={styles.featureContent}>
                  <Text style={styles.featureLabel}>{feature.label}</Text>
                  <Text style={styles.featureDescription}>{feature.description}</Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Recent Card Activity */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Recent Activity</Text>
          <View style={styles.activityList}>
            <View style={styles.activityItem}>
              <View style={styles.activityIcon}>
                <CreditCard size={20} color="#10b981" />
              </View>
              <View style={styles.activityContent}>
                <Text style={styles.activityTitle}>Card Payment</Text>
                <Text style={styles.activityDescription}>Amazon Purchase</Text>
                <Text style={styles.activityTime}>2 hours ago</Text>
              </View>
              <Text style={styles.activityAmount}>-$89.99</Text>
            </View>
            
            <View style={styles.activityItem}>
              <View style={styles.activityIcon}>
                <CreditCard size={20} color="#3b82f6" />
              </View>
              <View style={styles.activityContent}>
                <Text style={styles.activityTitle}>ATM Withdrawal</Text>
                <Text style={styles.activityDescription}>Main Street ATM</Text>
                <Text style={styles.activityTime}>Yesterday</Text>
              </View>
              <Text style={styles.activityAmount}>-$200.00</Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  headerTitle: {
    fontSize: 24,
    color: '#1f2937',
    fontWeight: '700',
  },
  addButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#ffffff',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  cardsContainer: {
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  card: {
    width: width - 80,
    height: 200,
    borderRadius: 16,
    padding: 20,
    marginRight: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 6,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  cardBank: {
    fontSize: 16,
    color: '#ffffff',
    fontWeight: '600',
  },
  cardType: {
    fontSize: 12,
    color: '#d1d5db',
    fontWeight: '500',
  },
  cardMiddle: {
    flex: 1,
    justifyContent: 'center',
  },
  cardNumber: {
    fontSize: 18,
    color: '#ffffff',
    fontWeight: '500',
    letterSpacing: 2,
  },
  cardFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
  },
  balanceLabel: {
    fontSize: 12,
    color: '#d1d5db',
    fontWeight: '400',
    marginBottom: 4,
  },
  balanceRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  balanceAmount: {
    fontSize: 16,
    color: '#ffffff',
    fontWeight: '600',
    marginRight: 8,
  },
  cardChip: {
    width: 32,
    height: 24,
    backgroundColor: '#fbbf24',
    borderRadius: 4,
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    color: '#1f2937',
    fontWeight: '600',
    marginBottom: 16,
  },
  featuresList: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f3f4f6',
  },
  featureIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#eff6ff',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  featureContent: {
    flex: 1,
  },
  featureLabel: {
    fontSize: 16,
    color: '#1f2937',
    fontWeight: '500',
    marginBottom: 2,
  },
  featureDescription: {
    fontSize: 14,
    color: '#6b7280',
    fontWeight: '400',
  },
  activityList: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  activityItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f3f4f6',
  },
  activityIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#f0fdf4',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  activityContent: {
    flex: 1,
  },
  activityTitle: {
    fontSize: 16,
    color: '#1f2937',
    fontWeight: '500',
    marginBottom: 2,
  },
  activityDescription: {
    fontSize: 14,
    color: '#6b7280',
    fontWeight: '400',
    marginBottom: 2,
  },
  activityTime: {
    fontSize: 12,
    color: '#9ca3af',
    fontWeight: '400',
  },
  activityAmount: {
    fontSize: 16,
    color: '#1f2937',
    fontWeight: '600',
  },
});