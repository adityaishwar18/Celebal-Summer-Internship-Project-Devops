import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput } from 'react-native';
import { ArrowUpRight, ArrowDownLeft, Users, Clock, Search } from 'lucide-react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

export default function TransferScreen() {
  const [amount, setAmount] = React.useState('');
  const [selectedContact, setSelectedContact] = React.useState(null);

  const quickAmounts = [50, 100, 200, 500];
  
  const recentContacts = [
    { id: 1, name: 'Sarah Johnson', avatar: 'SJ', lastTransfer: '$250' },
    { id: 2, name: 'Mike Chen', avatar: 'MC', lastTransfer: '$75' },
    { id: 3, name: 'Emma Wilson', avatar: 'EW', lastTransfer: '$120' },
    { id: 4, name: 'David Brown', avatar: 'DB', lastTransfer: '$300' },
  ];

  const transferOptions = [
    { icon: ArrowUpRight, label: 'Send Money', description: 'Transfer to contacts', color: '#ef4444' },
    { icon: ArrowDownLeft, label: 'Request Money', description: 'Request from contacts', color: '#10b981' },
    { icon: Users, label: 'Split Bill', description: 'Share expenses', color: '#3b82f6' },
    { icon: Clock, label: 'Scheduled', description: 'Set up recurring transfers', color: '#f59e0b' },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Transfer</Text>
        </View>

        {/* Transfer Options */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Transfer Options</Text>
          <View style={styles.optionsGrid}>
            {transferOptions.map((option, index) => (
              <TouchableOpacity key={index} style={styles.optionCard}>
                <View style={[styles.optionIcon, { backgroundColor: option.color }]}>
                  <option.icon size={24} color="#ffffff" />
                </View>
                <Text style={styles.optionLabel}>{option.label}</Text>
                <Text style={styles.optionDescription}>{option.description}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Amount Input */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Enter Amount</Text>
          <View style={styles.amountContainer}>
            <Text style={styles.currencySymbol}>$</Text>
            <TextInput
              style={styles.amountInput}
              value={amount}
              onChangeText={setAmount}
              placeholder="0.00"
              keyboardType="numeric"
              placeholderTextColor="#9ca3af"
            />
          </View>
          
          {/* Quick Amount Buttons */}
          <View style={styles.quickAmounts}>
            {quickAmounts.map((quickAmount) => (
              <TouchableOpacity
                key={quickAmount}
                style={styles.quickAmountButton}
                onPress={() => setAmount(quickAmount.toString())}
              >
                <Text style={styles.quickAmountText}>${quickAmount}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Recent Contacts */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Recent Contacts</Text>
            <TouchableOpacity style={styles.searchButton}>
              <Search size={20} color="#6b7280" />
            </TouchableOpacity>
          </View>
          
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.contactsScroll}>
            {recentContacts.map((contact) => (
              <TouchableOpacity
                key={contact.id}
                style={[
                  styles.contactCard,
                  selectedContact === contact.id && styles.selectedContact
                ]}
                onPress={() => setSelectedContact(contact.id)}
              >
                <View style={styles.avatar}>
                  <Text style={styles.avatarText}>{contact.avatar}</Text>
                </View>
                <Text style={styles.contactName}>{contact.name}</Text>
                <Text style={styles.lastTransfer}>Last: {contact.lastTransfer}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Transfer Button */}
        <View style={styles.section}>
          <TouchableOpacity
            style={[
              styles.transferButton,
              (!amount || !selectedContact) && styles.transferButtonDisabled
            ]}
            disabled={!amount || !selectedContact}
          >
            <Text style={styles.transferButtonText}>
              Send ${amount || '0.00'}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Security Notice */}
        <View style={styles.securityNotice}>
          <Text style={styles.securityText}>
            🔒 All transfers are secured with end-to-end encryption and require biometric authentication
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  headerTitle: {
    fontSize: 24,
    color: '#1f2937',
    fontWeight: '700',
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    color: '#1f2937',
    fontWeight: '600',
    marginBottom: 16,
  },
  searchButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#ffffff',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  optionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  optionCard: {
    width: '48%',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  optionIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  optionLabel: {
    fontSize: 16,
    color: '#1f2937',
    fontWeight: '600',
    marginBottom: 4,
    textAlign: 'center',
  },
  optionDescription: {
    fontSize: 12,
    color: '#6b7280',
    fontWeight: '400',
    textAlign: 'center',
  },
  amountContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 20,
    paddingVertical: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  currencySymbol: {
    fontSize: 24,
    color: '#1f2937',
    fontWeight: '600',
    marginRight: 8,
  },
  amountInput: {
    flex: 1,
    fontSize: 24,
    color: '#1f2937',
    fontWeight: '600',
  },
  quickAmounts: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  quickAmountButton: {
    flex: 1,
    backgroundColor: '#f3f4f6',
    borderRadius: 8,
    paddingVertical: 12,
    marginHorizontal: 4,
    alignItems: 'center',
  },
  quickAmountText: {
    fontSize: 14,
    color: '#374151',
    fontWeight: '500',
  },
  contactsScroll: {
    marginTop: 0,
  },
  contactCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginRight: 12,
    width: 120,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  selectedContact: {
    borderWidth: 2,
    borderColor: '#3b82f6',
  },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#3b82f6',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  avatarText: {
    fontSize: 16,
    color: '#ffffff',
    fontWeight: '600',
  },
  contactName: {
    fontSize: 14,
    color: '#1f2937',
    fontWeight: '500',
    textAlign: 'center',
    marginBottom: 4,
  },
  lastTransfer: {
    fontSize: 12,
    color: '#6b7280',
    fontWeight: '400',
    textAlign: 'center',
  },
  transferButton: {
    backgroundColor: '#3b82f6',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    shadowColor: '#3b82f6',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
  },
  transferButtonDisabled: {
    backgroundColor: '#d1d5db',
    shadowOpacity: 0,
    elevation: 0,
  },
  transferButtonText: {
    fontSize: 18,
    color: '#ffffff',
    fontWeight: '600',
  },
  securityNotice: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#f0f9ff',
    marginHorizontal: 20,
    borderRadius: 12,
    marginBottom: 24,
  },
  securityText: {
    fontSize: 14,
    color: '#1e40af',
    fontWeight: '400',
    textAlign: 'center',
    lineHeight: 20,
  },
});