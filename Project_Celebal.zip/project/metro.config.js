var getDefaultConfig = require('expo/metro-config').getDefaultConfig;

var config = getDefaultConfig(__dirname);

// Add web support
config.resolver.platforms = ['ios', 'android', 'native', 'web'];

module.exports = config;