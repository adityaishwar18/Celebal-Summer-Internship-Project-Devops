import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { Chrome as Home, CreditCard, ArrowUpDown, ChartBar as BarChart3, User, Menu, X } from 'lucide-react-native';

interface WebLayoutProps {
  children: React.ReactNode;
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export default function WebLayout({ children, activeTab, onTabChange }: WebLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = React.useState(false);

  const navigationItems = [
    { id: 'home', icon: Home, label: 'Dashboard', path: '/' },
    { id: 'cards', icon: CreditCard, label: 'Cards', path: '/cards' },
    { id: 'transfer', icon: ArrowUpDown, label: 'Transfer', path: '/transfer' },
    { id: 'analytics', icon: BarChart3, label: 'Analytics', path: '/analytics' },
    { id: 'profile', icon: User, label: 'Profile', path: '/profile' },
  ];

  return (
    <View style={styles.container}>
      {/* Mobile Header */}
      <View style={styles.mobileHeader}>
        <TouchableOpacity
          style={styles.menuButton}
          onPress={() => setSidebarOpen(!sidebarOpen)}
        >
          {sidebarOpen ? <X size={24} color="#1f2937" /> : <Menu size={24} color="#1f2937" />}
        </TouchableOpacity>
        <Text style={styles.headerTitle}>SecureBank</Text>
        <View style={styles.headerSpacer} />
      </View>

      <View style={styles.mainContainer}>
        {/* Sidebar */}
        <View style={[styles.sidebar, sidebarOpen && styles.sidebarOpen]}>
          <View style={styles.sidebarHeader}>
            <Text style={styles.sidebarTitle}>SecureBank</Text>
            <Text style={styles.sidebarSubtitle}>Digital Banking</Text>
          </View>
          
          <ScrollView style={styles.sidebarContent}>
            {navigationItems.map((item) => (
              <TouchableOpacity
                key={item.id}
                style={[
                  styles.sidebarItem,
                  activeTab === item.id && styles.sidebarItemActive
                ]}
                onPress={() => {
                  onTabChange(item.id);
                  setSidebarOpen(false);
                }}
              >
                <item.icon
                  size={20}
                  color={activeTab === item.id ? '#3b82f6' : '#6b7280'}
                />
                <Text style={[
                  styles.sidebarItemText,
                  activeTab === item.id && styles.sidebarItemTextActive
                ]}>
                  {item.label}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Main Content */}
        <View style={styles.content}>
          {children}
        </View>
      </View>

      {/* Mobile Overlay */}
      {sidebarOpen && (
        <TouchableOpacity
          style={styles.overlay}
          onPress={() => setSidebarOpen(false)}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  mobileHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
    // @ts-ignore
    '@media (min-width: 768px)': {
      display: 'none',
    },
  },
  menuButton: {
    padding: 8,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1f2937',
    marginLeft: 12,
  },
  headerSpacer: {
    flex: 1,
  },
  mainContainer: {
    flex: 1,
    flexDirection: 'row',
  },
  sidebar: {
    width: 280,
    backgroundColor: '#ffffff',
    borderRightWidth: 1,
    borderRightColor: '#e5e7eb',
    position: 'absolute',
    left: -280,
    top: 0,
    bottom: 0,
    zIndex: 1000,
    // @ts-ignore
    '@media (min-width: 768px)': {
      position: 'relative',
      left: 0,
    },
  },
  sidebarOpen: {
    left: 0,
  },
  sidebarHeader: {
    padding: 24,
    borderBottomWidth: 1,
    borderBottomColor: '#f3f4f6',
  },
  sidebarTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#1f2937',
    marginBottom: 4,
  },
  sidebarSubtitle: {
    fontSize: 14,
    color: '#6b7280',
    fontWeight: '500',
  },
  sidebarContent: {
    flex: 1,
    padding: 16,
  },
  sidebarItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 8,
    marginBottom: 4,
  },
  sidebarItemActive: {
    backgroundColor: '#eff6ff',
  },
  sidebarItemText: {
    fontSize: 16,
    color: '#6b7280',
    fontWeight: '500',
    marginLeft: 12,
  },
  sidebarItemTextActive: {
    color: '#3b82f6',
    fontWeight: '600',
  },
  content: {
    flex: 1,
    // @ts-ignore
    '@media (min-width: 768px)': {
      marginLeft: 0,
    },
  },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    zIndex: 999,
    // @ts-ignore
    '@media (min-width: 768px)': {
      display: 'none',
    },
  },
});