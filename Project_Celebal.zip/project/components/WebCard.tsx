import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';

interface WebCardProps {
  children: React.ReactNode;
  style?: any;
  onPress?: () => void;
}

export default function WebCard({ children, style, onPress }: WebCardProps) {
  const CardComponent = onPress ? TouchableOpacity : View;
  
  return (
    <CardComponent style={[styles.card, style]} onPress={onPress}>
      {children}
    </CardComponent>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
    // @ts-ignore
    '@media (min-width: 768px)': {
      shadowOffset: { width: 0, height: 4 },
      shadowOpacity: 0.05,
      shadowRadius: 12,
    },
  },
});