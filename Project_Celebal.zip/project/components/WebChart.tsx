+import React from 'react';
+import { View, Text, StyleSheet } from 'react-native';
+
+interface ChartData {
+  month: string;
+  income: number;
+  expenses: number;
+}
+
+interface WebChartProps {
+  data: ChartData[];
+}
+
+export default function WebChart({ data }: WebChartProps) {
+  const maxValue = Math.max(...data.map(d => Math.max(d.income, d.expenses)));
+
+  return (
+    <View style={styles.container}>
+      <View style={styles.chart}>
+        {data.map((item, index) => (
+          <View key={index} style={styles.chartBar}>
+            <View style={styles.barContainer}>
+              <View
+                style={[
+                  styles.bar,
+                  styles.incomeBar,
+                  { height: (item.income / maxValue) * 120 }
+                ]}
+              />
+              <View
+                style={[
+                  styles.bar,
+                  styles.expenseBar,
+                  { height: (item.expenses / maxValue) * 120 }
+                ]}
+              />
+            </View>
+            <Text style={styles.monthLabel}>{item.month}</Text>
+          </View>
+        ))}
+      </View>
+      
+      <View style={styles.legend}>
+        <View style={styles.legendItem}>
+          <View style={[styles.legendColor, { backgroundColor: '#3b82f6' }]} />
+          <Text style={styles.legendText}>Income</Text>
+        </View>
+        <View style={styles.legendItem}>
+          <View style={[styles.legendColor, { backgroundColor: '#ef4444' }]} />
+          <Text style={styles.legendText}>Expenses</Text>
+        </View>
+      </View>
+    </View>
+  );
+}
+
+const styles = StyleSheet.create({
+  container: {
+    backgroundColor: '#ffffff',
+    borderRadius: 12,
+    padding: 20,
+    shadowColor: '#000',
+    shadowOffset: { width: 0, height: 2 },
+    shadowOpacity: 0.05,
+    shadowRadius: 8,
+    elevation: 2,
+  },
+  chart: {
+    flexDirection: 'row',
+    justifyContent: 'space-between',
+    alignItems: 'flex-end',
+    height: 140,
+    marginBottom: 20,
+  },
+  chartBar: {
+    alignItems: 'center',
+    flex: 1,
+  },
+  barContainer: {
+    flexDirection: 'row',
+    alignItems: 'flex-end',
+    marginBottom: 8,
+  },
+  bar: {
+    width: 56,
+    borderRadius: 4,
+    marginHorizontal: 2,
+    minHeight: 4,
+  },
+  incomeBar: {
+    backgroundColor: '#3b82f6',
+  },
+  expenseBar: {
+    backgroundColor: '#ef4444',
+  },
+  monthLabel: {
+    fontSize: 12,
+    color: '#6b7280',
+    fontWeight: '500',
+  },
+  legend: {
+    flexDirection: 'row',
+    justifyContent: 'center',
+    gap: 24,
+  },
+  legendItem: {
+    flexDirection: 'row',
+    alignItems: 'center',
+  },
+  legendColor: {
+    width: 12,
+    height: 12,
+    borderRadius: 6,
+    marginRight: 8,
+  },
+  legendText: {
+    fontSize: 14,
+    color: '#6b7280',
+    fontWeight: '500',
+  },
+});