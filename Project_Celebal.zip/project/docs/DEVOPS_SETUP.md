# DevOps Pipeline Setup Guide for Mobile Banking App

This guide provides comprehensive instructions for setting up Azure DevOps pipelines for the mobile banking application with enterprise-grade security and compliance.

## Prerequisites

### Azure DevOps Setup
1. **Azure DevOps Organization**: Create or use existing Azure DevOps organization
2. **Project Creation**: Create a new project for the mobile banking app
3. **Service Connections**: Set up required service connections
4. **Variable Groups**: Configure secure variable groups

### Required Service Connections

#### 1. Azure Service Connection
```yaml
Name: Azure-Service-Connection
Type: Azure Resource Manager
Subscription: Your Azure Subscription
Resource Group: mobile-banking-rg
```

#### 2. Google Play Store Connection
```yaml
Name: Google-Play-Service-Connection
Type: Google Play
Service Account Key: Upload your service account JSON key
```

#### 3. Apple App Store Connection
```yaml
Name: Apple-App-Store-Service-Connection
Type: Apple App Store
Apple ID: Your Apple Developer Account
Password: App-specific password
```

#### 4. SonarCloud Connection
```yaml
Name: SonarCloud-Connection
Type: SonarCloud
Organization: your-sonarcloud-org
Token: Your SonarCloud token
```

## Variable Groups Configuration

### 1. Mobile Banking Secrets
Create a variable group named `mobile-banking-secrets` with the following variables:

```yaml
Variable Group: mobile-banking-secrets
Variables:
  - expo-token: [Your Expo access token] (Secret)
  - android-keystore-password: [Android keystore password] (Secret)
  - ios-cert-password: [iOS certificate password] (Secret)
  - subscription-id: [Azure subscription ID]
  - sonar-token: [SonarCloud token] (Secret)
```

## Azure Key Vault Setup

### 1. Create Key Vault
```bash
# Create resource group
az group create --name mobile-banking-rg --location eastus

# Create Key Vault
az keyvault create \
  --name mobile-banking-keyvault \
  --resource-group mobile-banking-rg \
  --location eastus \
  --enable-rbac-authorization
```

### 2. Store Secrets
```bash
# Store Expo token
az keyvault secret set \
  --vault-name mobile-banking-keyvault \
  --name expo-token \
  --value "your-expo-token"

# Store Android keystore password
az keyvault secret set \
  --vault-name mobile-banking-keyvault \
  --name android-keystore-password \
  --value "your-keystore-password"
```

## Security Configuration

### 1. SonarCloud Setup
1. Create account at [SonarCloud](https://sonarcloud.io)
2. Create new project for mobile banking app
3. Generate authentication token
4. Configure quality gates and security rules

### 2. OWASP ZAP Configuration
```yaml
# Add to pipeline variables
zap-baseline-url: https://your-staging-api.com
zap-api-scan: true
zap-spider-scan: true
```

### 3. Mobile Security Framework (MobSF)
- Set up MobSF instance for mobile app security testing
- Configure API endpoints for automated scanning
- Define security thresholds and failure criteria

## Certificate Management

### 1. Android Signing
```bash
# Generate Android keystore (if not exists)
keytool -genkey -v -keystore mobile-banking.keystore \
  -alias mobile-banking -keyalg RSA -keysize 2048 -validity 10000

# Upload keystore to Azure DevOps Secure Files
# Configure signing in build pipeline
```

### 2. iOS Certificates
1. Generate iOS distribution certificate in Apple Developer Portal
2. Create provisioning profile for production
3. Export certificate as .p12 file
4. Upload to Azure DevOps Secure Files

## Pipeline Configuration

### 1. Branch Policies
Configure branch policies for main and develop branches:

```yaml
Branch Protection Rules:
  - Require pull request reviews: 2 reviewers
  - Require status checks: All pipeline stages must pass
  - Require branches to be up to date
  - Restrict pushes to main branch
  - Require signed commits
```

### 2. Environment Setup
Create environments in Azure DevOps:

#### Staging Environment
```yaml
Name: staging
Approvals: Automatic
Checks:
  - Security scan results must pass
  - Unit test coverage > 80%
```

#### Production Environment
```yaml
Name: production
Approvals: Manual (2 approvers required)
Checks:
  - All security scans passed
  - Performance tests passed
  - Business approval required
```

## Monitoring and Alerting

### 1. Application Insights
```bash
# Create Application Insights resource
az monitor app-insights component create \
  --app mobile-banking-ai \
  --location eastus \
  --resource-group mobile-banking-rg \
  --application-type web
```

### 2. Security Monitoring
Configure alerts for:
- High error rates (>10 errors/minute)
- Unusual authentication patterns
- API rate limit violations
- Security scan failures
- Certificate expiration warnings

### 3. Performance Monitoring
Set up monitoring for:
- App launch time
- API response times
- Crash rates
- User session metrics

## Compliance and Governance

### 1. Audit Logging
- Enable Azure DevOps audit logging
- Configure log retention policies
- Set up log analysis and alerting

### 2. Access Control
```yaml
Security Groups:
  - Mobile-Banking-Developers: Read, Contribute
  - Mobile-Banking-Leads: Read, Contribute, Manage
  - Mobile-Banking-Admins: Full Control
  - Security-Team: Read, Security Scans
```

### 3. Compliance Checks
- PCI DSS compliance validation
- SOX compliance reporting
- GDPR data protection verification
- Regular security assessments

## Deployment Strategies

### 1. Blue-Green Deployment
```yaml
Strategy: Blue-Green
Staging Slot: Blue environment
Production Slot: Green environment
Rollback: Automatic on failure detection
```

### 2. Canary Releases
```yaml
Strategy: Canary
Initial Release: 5% of users
Gradual Rollout: 25%, 50%, 100%
Success Criteria: Error rate < 1%, Performance baseline maintained
```

### 3. Feature Flags
Implement feature flags for:
- New banking features
- UI/UX changes
- Security enhancements
- Performance optimizations

## Disaster Recovery

### 1. Backup Strategy
- Daily automated backups of pipeline configurations
- Source code backup to multiple repositories
- Certificate and secret backup procedures

### 2. Recovery Procedures
- Pipeline restoration from backup
- Emergency deployment procedures
- Rollback strategies for critical issues

## Best Practices

### 1. Security
- Never store secrets in source code
- Use managed identities where possible
- Implement least privilege access
- Regular security reviews and updates

### 2. Performance
- Optimize build times with caching
- Parallel job execution
- Incremental builds when possible
- Resource optimization

### 3. Reliability
- Comprehensive error handling
- Retry mechanisms for transient failures
- Health checks and monitoring
- Automated recovery procedures

## Troubleshooting

### Common Issues
1. **Build Failures**: Check dependency versions and cache
2. **Security Scan Failures**: Review and fix identified vulnerabilities
3. **Deployment Issues**: Verify certificates and provisioning profiles
4. **Performance Issues**: Optimize pipeline stages and resource allocation

### Support Contacts
- DevOps Team: devops@securebank.com
- Security Team: security@securebank.com
- Mobile Team: mobile-dev@securebank.com

## Maintenance

### Regular Tasks
- Monthly security updates
- Quarterly certificate renewal checks
- Annual compliance audits
- Performance optimization reviews

This setup ensures enterprise-grade security, compliance, and reliability for the mobile banking application deployment pipeline.